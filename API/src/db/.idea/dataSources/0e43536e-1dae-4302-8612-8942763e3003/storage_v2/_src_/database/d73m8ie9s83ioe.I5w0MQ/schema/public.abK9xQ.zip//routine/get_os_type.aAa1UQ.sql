create function get_os_type(os_id numeric) returns name
    language plpgsql
as
$$
DECLARE
        result varchar(100);
BEGIN
    result := (SELECT name FROM operating_systems as os WHERE os_id = os.id);
        CASE
            WHEN result IS NOT NULL
            THEN RETURN result;
        ELSE
            result := '';
            RETURN result;
        END CASE;
END
$$;

alter function get_os_type(numeric) owner to ljfcticwoomtmp;

